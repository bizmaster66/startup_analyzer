# Startup Analyzer Pro

## 설치
pip install -r requirements.txt

## 실행
streamlit run app.py
